Port of Adafruit's library for ILI9341 to ESP8266 (WF8266R)
Uses HSPI.
Wiring:
ILI9341 pin	ESP8266 pin
MISO 		GPIO12
MOSI 		GPIO13
SCK 		GPIO14
CS 		GPIO15
DC 		GPIO5

Reset		3V3
LED		through 50-60 Ohm resistor to 3V3